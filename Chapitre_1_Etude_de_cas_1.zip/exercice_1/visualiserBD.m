function visualiserBD(X,y)
    plot(X,y ,'rx');
    xlabel('population ville');
    ylabel('Gain (dh)');
end